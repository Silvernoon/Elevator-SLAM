/*******************************************************
 * Copyright (C) 2019, Aerial Robotics Group, Hong Kong University of Science and Technology
 *
 * This file is part of VINS.
 *
 * Licensed under the GNU General Public License v3.0;
 * you may not use this file except in compliance with the License.
 *
 * Author: Qin Tong (qintonguav@gmail.com)
 *******************************************************/

#include "feature_tracker.h"

bool FeatureTracker::inBorder(const cv::Point2f &pt)
{
    const int BORDER_SIZE = 1;
    int img_x = cvRound(pt.x);
    int img_y = cvRound(pt.y);
    return BORDER_SIZE <= img_x && img_x < col - BORDER_SIZE && BORDER_SIZE <= img_y && img_y < row - BORDER_SIZE;
}

double distance(cv::Point2f pt1, cv::Point2f pt2)
{
    // printf("pt1: %f %f pt2: %f %f\n", pt1.x, pt1.y, pt2.x, pt2.y);
    double dx = pt1.x - pt2.x;
    double dy = pt1.y - pt2.y;
    return sqrt(dx * dx + dy * dy);
}

void reduceVector(vector<cv::Point2f> &v, vector<uchar> status)
{
    int j = 0;
    for (int i = 0; i < int(v.size()); i++)
        if (status[i])
            v[j++] = v[i];
    v.resize(j);
}

void reduceVector(vector<int> &v, vector<uchar> status)
{
    int j = 0;
    for (int i = 0; i < int(v.size()); i++)
        if (status[i])
            v[j++] = v[i];
    v.resize(j);
}

FeatureTracker::FeatureTracker()
{
    stereo_cam = 0;
    depth_cam = 0;
    n_id = 0;
    hasPrediction = false;
}

void FeatureTracker::setMask()
{
    mask = cv::Mat(row, col, CV_8UC1, cv::Scalar(255));

    // prefer to keep features that are tracked for long time
    vector<pair<int, pair<cv::Point2f, int>>> cnt_pts_id;

    for (unsigned int i = 0; i < cur_pts.size(); i++)
        cnt_pts_id.push_back(make_pair(track_cnt[i], make_pair(cur_pts[i], ids[i])));

    sort(cnt_pts_id.begin(), cnt_pts_id.end(), [](const pair<int, pair<cv::Point2f, int>> &a, const pair<int, pair<cv::Point2f, int>> &b)
         { return a.first > b.first; });

    cur_pts.clear();
    ids.clear();
    track_cnt.clear();

    for (auto &it : cnt_pts_id)
    {
        if (mask.at<uchar>(it.second.first) == 255)
        {
            cur_pts.push_back(it.second.first);
            ids.push_back(it.second.second);
            track_cnt.push_back(it.first);
            cv::circle(mask, it.second.first, MIN_DIST, 0, -1);
        }
    }
}

void FeatureTracker::addPoints()
{
    for (auto &p : n_pts)
    {
        cur_pts.push_back(p);
        ids.push_back(n_id++);
        track_cnt.push_back(1);
    }
}

double FeatureTracker::distance(cv::Point2f &pt1, cv::Point2f &pt2)
{
    // printf("pt1: %f %f pt2: %f %f\n", pt1.x, pt1.y, pt2.x, pt2.y);
    double dx = pt1.x - pt2.x;
    double dy = pt1.y - pt2.y;
    return sqrt(dx * dx + dy * dy);
}

map<int, vector<pair<int, Eigen::Matrix<double, 8, 1>>>> FeatureTracker::trackImage(double _cur_time, const cv::Mat &_img, const cv::Mat &_img1)
{
    TicToc t_r;
    cur_time = _cur_time;
    cur_img = _img;
    row = cur_img.rows;
    col = cur_img.cols;
    cv::Mat rightImg = _img1;
    cur_pts.clear();

    if (prev_pts.size() > 0)
    {
        TicToc t_o;
        vector<uchar> status;
        vector<float> err;
        if (hasPrediction)
        {
            // cout<<"hasprediction"<<endl;
            cur_pts = predict_pts;
            cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 1,
                                     cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 0.01), cv::OPTFLOW_USE_INITIAL_FLOW);

            int succ_num = 0;
            for (size_t i = 0; i < status.size(); i++)
            {
                if (status[i])
                    succ_num++;
            }
            if (succ_num < 10)
                cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 3);
        }
        else
            cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 3);
        // reverse check
        if (FLOW_BACK)
        {
            vector<uchar> reverse_status;
            vector<cv::Point2f> reverse_pts = prev_pts;
            cv::calcOpticalFlowPyrLK(cur_img, prev_img, cur_pts, reverse_pts, reverse_status, err, cv::Size(21, 21), 1,
                                     cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 0.01), cv::OPTFLOW_USE_INITIAL_FLOW);
            // cv::calcOpticalFlowPyrLK(cur_img, prev_img, cur_pts, reverse_pts, reverse_status, err, cv::Size(21, 21), 3);
            for (size_t i = 0; i < status.size(); i++)
            {
                if (status[i] && reverse_status[i] && distance(prev_pts[i], reverse_pts[i]) <= 0.5)
                {
                    status[i] = 1;
                }
                else
                    status[i] = 0;
            }
        }

        for (int i = 0; i < int(cur_pts.size()); i++)
        {
            if (status[i] && !inBorder(cur_pts[i]))
                status[i] = 0;
            int p_u, p_v;
            p_u = (int)cur_pts[i].x;
            p_v = (int)cur_pts[i].y;
            uchar grey = cur_img.at<uchar>(p_v, p_u);
            if (status[i] && grey > 250)
            {
                status[i] = 0;
                // cout<<grey<<endl;
            }
        }

        reduceVector(prev_pts, status);
        reduceVector(cur_pts, status);
        reduceVector(ids, status);
        reduceVector(track_cnt, status);
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "temporal optical flow costs: %fms", t_o.toc());
        // printf("track cnt %d\n", (int)ids.size());
    }

    for (auto &n : track_cnt)
        n++;

    if (1)
    {
        // rejectWithF();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "set mask begins");
        TicToc t_m;
        setMask();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "set mask costs %fms", t_m.toc());

        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "detect feature begins");
        TicToc t_t;
        int n_max_cnt = MAX_CNT - static_cast<int>(cur_pts.size());
        if (n_max_cnt > 0)
        {
            if (mask.empty())
                cout << "mask is empty " << endl;
            if (mask.type() != CV_8UC1)
                cout << "mask type wrong " << endl;
            cv::goodFeaturesToTrack(cur_img, n_pts, MAX_CNT - cur_pts.size(), 0.01, MIN_DIST, mask);
        }
        else
            n_pts.clear();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "detect feature costs: %fms", t_t.toc());

        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "add feature begins");
        TicToc t_a;
        addPoints();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "selectFeature costs: %fms", t_a.toc());
    }

    cur_un_pts = undistortedPts(cur_pts, m_camera[0]);
    pts_velocity = ptsVelocity(ids, cur_un_pts, cur_un_pts_map, prev_un_pts_map);

    // if (!_img1.empty() && depth_cam)
    if (depth_cam)
    {
        ids_right.clear();
        cur_right_pts.clear();
        cur_un_right_pts.clear();
        right_pts_velocity.clear();
        cur_un_right_pts_map.clear();
        if (!cur_pts.empty())
        {
            ids_right = ids;
            cur_right_pts = cur_pts;
            cur_un_right_pts = cur_un_pts;
            size_t N = cur_pts.size();
            vector<uchar> status(N, 0);
            for (size_t i = 0; i < N; i++)
            {
                int p_u, p_v;
                p_u = (int)cur_pts[i].x;
                p_v = (int)cur_pts[i].y;
                // float d = 1.15 * rightImg.ptr<unsigned short>(p_v)[p_u];
                // cout <<d<<endl;
                // if(d > 0 && d < 7000)
                if (1)
                {
                    // cur_un_right_pts[i].x = cur_un_pts[i].x - 100.0 / d;
                    cur_un_right_pts[i].x = cur_un_pts[i].x;
                    cur_un_right_pts[i].y = cur_un_pts[i].y;
                    // cout <<cur_un_right_pts[i].x<<endl;
                    status[i] = 1;
                }
            }
            reduceVector(cur_right_pts, status);
            reduceVector(cur_un_right_pts, status);
            reduceVector(ids_right, status);

            reduceVector(cur_pts, status);
            reduceVector(ids, status);
            reduceVector(track_cnt, status);
            reduceVector(cur_un_pts, status);
            reduceVector(pts_velocity, status);

            right_pts_velocity = ptsVelocity(ids_right, cur_un_right_pts, cur_un_right_pts_map, prev_un_right_pts_map);
        }
        prev_un_right_pts_map = cur_un_right_pts_map;
    }
    // else if(!_img1.empty() && stereo_cam)
    // {
    //     ids_right.clear();
    //     cur_right_pts.clear();
    //     cur_un_right_pts.clear();
    //     right_pts_velocity.clear();
    //     cur_un_right_pts_map.clear();
    //     if(!cur_pts.empty())
    //     {
    //         //printf("stereo image; track feature on right image\n");
    //         vector<cv::Point2f> reverseLeftPts;
    //         vector<uchar> status, statusRightLeft;
    //         vector<float> err;
    //         // cur left ---- cur right
    //         cv::calcOpticalFlowPyrLK(cur_img, rightImg, cur_pts, cur_right_pts, status, err, cv::Size(21, 21), 3);
    //         // reverse check cur right ---- cur left
    //         if(FLOW_BACK)
    //         {
    //             cv::calcOpticalFlowPyrLK(rightImg, cur_img, cur_right_pts, reverseLeftPts, statusRightLeft, err, cv::Size(21, 21), 3);
    //             for(size_t i = 0; i < status.size(); i++)
    //             {
    //                 if(status[i] && statusRightLeft[i] && inBorder(cur_right_pts[i]) && distance(cur_pts[i], reverseLeftPts[i]) <= 0.5)
    //                     status[i] = 1;
    //                 else
    //                     status[i] = 0;
    //             }
    //         }

    //         ids_right = ids;
    //         reduceVector(cur_right_pts, status);
    //         reduceVector(ids_right, status);
    //         // only keep left-right pts
    //         /*
    //         reduceVector(cur_pts, status);
    //         reduceVector(ids, status);
    //         reduceVector(track_cnt, status);
    //         reduceVector(cur_un_pts, status);
    //         reduceVector(pts_velocity, status);
    //         */
    //         cur_un_right_pts = undistortedPts(cur_right_pts, m_camera[1]);
    //         right_pts_velocity = ptsVelocity(ids_right, cur_un_right_pts, cur_un_right_pts_map, prev_un_right_pts_map);
    //         //cout <<pts_velocity[0].x << ":" <<right_pts_velocity[0].x<<endl;
    //     }
    //     prev_un_right_pts_map = cur_un_right_pts_map;
    // }
    if (SHOW_TRACK)
        drawTrack(cur_img, rightImg, ids, cur_pts, cur_right_pts, prevLeftPtsMap);

    prev_img = cur_img;
    prev_pts = cur_pts;
    prev_un_pts = cur_un_pts;
    prev_un_pts_map = cur_un_pts_map;
    prev_time = cur_time;
    hasPrediction = false;

    prevLeftPtsMap.clear();
    for (size_t i = 0; i < cur_pts.size(); i++)
        prevLeftPtsMap[ids[i]] = cur_pts[i];

    map<int, vector<pair<int, Eigen::Matrix<double, 8, 1>>>> featureFrame;
    // cout<<"depth cam"<<depth_cam<<endl;
    if (depth_cam == 0)
    {
        for (size_t i = 0; i < ids.size(); i++) // for vinsmono,no depth
        {
            int feature_id = ids[i];
            double x, y, z;
            x = cur_un_pts[i].x;
            y = cur_un_pts[i].y;
            z = 1;
            double p_u, p_v;
            p_u = cur_pts[i].x;
            p_v = cur_pts[i].y;
            int camera_id = 0;
            double velocity_x, velocity_y;
            velocity_x = pts_velocity[i].x;
            velocity_y = pts_velocity[i].y;

            Eigen::Matrix<double, 8, 1> xyz_uv_velocity;
            double depthmono = -2.4; // for debug
            xyz_uv_velocity << x, y, z, p_u, p_v, velocity_x, velocity_y, depthmono;
            featureFrame[feature_id].emplace_back(camera_id, xyz_uv_velocity);
        }
    }

    if (!_img1.empty() && (stereo_cam || depth_cam))
    {
        for (size_t i = 0; i < ids.size(); i++)
        {
            int feature_id = ids[i];
            double x, y, z;
            x = cur_un_pts[i].x;
            y = cur_un_pts[i].y;
            z = 1;
            double p_u, p_v;
            p_u = cur_pts[i].x;
            p_v = cur_pts[i].y;
            int camera_id = 0;
            double velocity_x, velocity_y;
            velocity_x = pts_velocity[i].x;
            velocity_y = pts_velocity[i].y;
            double depth_value = (int)rightImg.at<unsigned short>(round(cur_pts[i].y), round(cur_pts[i].x));
            depth_value = depth_value / 1000;
            // cout << "depth value" << depth_value << endl;

            Eigen::Matrix<double, 8, 1> xyz_uv_velocity;
            xyz_uv_velocity << x, y, z, p_u, p_v, velocity_x, velocity_y, depth_value;
            featureFrame[feature_id].emplace_back(camera_id, xyz_uv_velocity);
        }
    }

    // printf("feature track whole time %f\n", t_r.toc());
    return featureFrame;
}

map<int, vector<pair<int, Eigen::Matrix<double, 8, 1>>>> FeatureTracker::trackImagebox(double _cur_time, const darknet_ros_msgs::msg::BoundingBoxes::ConstSharedPtr &_boxes, const cv::Mat &_img, const cv::Mat &_img1)
{
    TicToc t_r;
    cur_time = _cur_time;
    cur_img = _img;
    row = cur_img.rows;
    col = cur_img.cols;
    cv::Mat rightImg = _img1;
    cur_pts.clear();

    if (prev_pts.size() > 0)
    {
        TicToc t_o;
        vector<uchar> status;
        vector<float> err;
        if (hasPrediction)
        {
            // cout<<"hasprediction"<<endl;
            cur_pts = predict_pts;
            cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 1,
                                     cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 0.01), cv::OPTFLOW_USE_INITIAL_FLOW);

            int succ_num = 0;
            for (size_t i = 0; i < status.size(); i++)
            {
                if (status[i])
                    succ_num++;
            }
            if (succ_num < 10)
                cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 3);
        }
        else
            cv::calcOpticalFlowPyrLK(prev_img, cur_img, prev_pts, cur_pts, status, err, cv::Size(21, 21), 3);
        // reverse check
        if (FLOW_BACK)
        {
            vector<uchar> reverse_status;
            vector<cv::Point2f> reverse_pts = prev_pts;
            cv::calcOpticalFlowPyrLK(cur_img, prev_img, cur_pts, reverse_pts, reverse_status, err, cv::Size(21, 21), 1,
                                     cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 0.01), cv::OPTFLOW_USE_INITIAL_FLOW);
            // cv::calcOpticalFlowPyrLK(cur_img, prev_img, cur_pts, reverse_pts, reverse_status, err, cv::Size(21, 21), 3);
            for (size_t i = 0; i < status.size(); i++)
            {
                if (status[i] && reverse_status[i] && distance(prev_pts[i], reverse_pts[i]) <= 0.5)
                {
                    status[i] = 1;
                }
                else
                    status[i] = 0;
            }
        }

        for (int i = 0; i < int(cur_pts.size()); i++)
        {
            if (status[i] && !inBorder(cur_pts[i]))
                status[i] = 0;
            int p_u, p_v;
            p_u = (int)cur_pts[i].x;
            p_v = (int)cur_pts[i].y;
            uchar grey = cur_img.at<uchar>(p_v, p_u);
            if (status[i] && grey > 250)
            {
                status[i] = 0;
                // cout<<grey<<endl;
            }
        }

        reduceVector(prev_pts, status);
        reduceVector(cur_pts, status);
        reduceVector(ids, status);
        reduceVector(track_cnt, status);
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "temporal optical flow costs: %fms", t_o.toc());
        // printf("track cnt %d\n", (int)ids.size());
    }

    for (auto &n : track_cnt)
        n++;

    if (1)
    {
        // rejectWithF();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "set mask begins");
        TicToc t_m;
        setMask();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "set mask costs %fms", t_m.toc());

        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "detect feature begins");
        TicToc t_t;
        int n_max_cnt = MAX_CNT - static_cast<int>(cur_pts.size());
        if (n_max_cnt > 0)
        {
            if (mask.empty())
                cout << "mask is empty " << endl;
            if (mask.type() != CV_8UC1)
                cout << "mask type wrong " << endl;
            cv::goodFeaturesToTrack(cur_img, n_pts, MAX_CNT - cur_pts.size(), 0.01, MIN_DIST, mask);
        }
        else
            n_pts.clear();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "detect feature costs: %fms", t_t.toc());

        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "add feature begins");
        TicToc t_a;
        addPoints();
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "selectFeature costs: %fms", t_a.toc());
    }

    cur_un_pts = undistortedPts(cur_pts, m_camera[0]);
    pts_velocity = ptsVelocity(ids, cur_un_pts, cur_un_pts_map, prev_un_pts_map);

    // if (!_img1.empty() && depth_cam)
    if (depth_cam)
    {
        ids_right.clear();
        cur_right_pts.clear();
        cur_un_right_pts.clear();
        right_pts_velocity.clear();
        cur_un_right_pts_map.clear();
        if (!cur_pts.empty())
        {
            ids_right = ids;
            cur_right_pts = cur_pts;
            cur_un_right_pts = cur_un_pts;
            size_t N = cur_pts.size();
            vector<uchar> status(N, 0);
            for (size_t i = 0; i < N; i++)
            {
                int p_u, p_v;
                p_u = (int)cur_pts[i].x;
                p_v = (int)cur_pts[i].y;
                // float d = 1.15 * rightImg.ptr<unsigned short>(p_v)[p_u];
                // cout <<d<<endl;
                // if(d > 0 && d < 7000)
                if (1)
                {
                    // cur_un_right_pts[i].x = cur_un_pts[i].x - 100.0 / d;
                    cur_un_right_pts[i].x = cur_un_pts[i].x;
                    cur_un_right_pts[i].y = cur_un_pts[i].y;
                    // cout <<cur_un_right_pts[i].x<<endl;
                    status[i] = 1;
                }
            }
            reduceVector(cur_right_pts, status);
            reduceVector(cur_un_right_pts, status);
            reduceVector(ids_right, status);

            reduceVector(cur_pts, status);
            reduceVector(ids, status);
            reduceVector(track_cnt, status);
            reduceVector(cur_un_pts, status);
            reduceVector(pts_velocity, status);

            right_pts_velocity = ptsVelocity(ids_right, cur_un_right_pts, cur_un_right_pts_map, prev_un_right_pts_map);
        }
        prev_un_right_pts_map = cur_un_right_pts_map;
    }

    if (SHOW_TRACK)
        drawTrackbox(_boxes, cur_img, rightImg, ids, cur_pts, cur_right_pts, prevLeftPtsMap);

    prev_img = cur_img;
    prev_pts = cur_pts;
    prev_un_pts = cur_un_pts;
    prev_un_pts_map = cur_un_pts_map;
    prev_time = cur_time;
    hasPrediction = false;

    prevLeftPtsMap.clear();
    for (size_t i = 0; i < cur_pts.size(); i++)
        prevLeftPtsMap[ids[i]] = cur_pts[i];

    map<int, vector<pair<int, Eigen::Matrix<double, 8, 1>>>> featureFrame;
    // cout<<"depth cam"<<depth_cam<<endl;
    if (depth_cam == 0)
    {
        for (size_t i = 0; i < ids.size(); i++) // for vinsmono,no depth
        {
            int feature_id = ids[i];
            double x, y, z;
            x = cur_un_pts[i].x;
            y = cur_un_pts[i].y;
            z = 1;
            double p_u, p_v;
            p_u = cur_pts[i].x;
            p_v = cur_pts[i].y;
            int camera_id = 0;
            double velocity_x, velocity_y;
            velocity_x = pts_velocity[i].x;
            velocity_y = pts_velocity[i].y;

            // 在这里加入box的遍历，判断是否在轮廓内即可
            darknet_ros_msgs::msg::BoundingBoxes::ConstSharedPtr boxes = _boxes;

            darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes.front();
            int lengh = boxes->bounding_boxes.size();
            int insidebox = 0;
            for (int j = 0; j < lengh; j++)
            {
                darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes[j];
                int xmin = box.xmin;
                int ymin = box.ymin;
                int xmax = box.xmax;
                int ymax = box.ymax;

                cv::Rect rect(xmin, ymin, xmax - xmin, ymax - ymin);
                // cv::line(imTrack,Point(50,50),Point(90,70),Scalar(255,0,0),1,8,0);
                cv::rectangle(imTrack, rect, cv::Scalar(0, 128, 255), 5, cv::LINE_8, 0);
                // boxes->bounding_boxes.pop();
                // point inside
                vector<cv::Point2f> contour;
                contour.push_back({xmin, ymin});
                contour.push_back({xmin, ymax});
                contour.push_back({xmax, ymax});
                contour.push_back({xmax, ymin});

                if (double distance = pointPolygonTest(contour, cur_pts[i], true) > 0)
                {
                    insidebox = 1;
                    // cout<<"insidebox"<<insidebox<<endl;
                    continue;
                }
            }
            if (insidebox)
            {
                continue;
            }
            else
            {
                Eigen::Matrix<double, 8, 1> xyz_uv_velocity;
                double depthmono = -2.4; // for debug
                xyz_uv_velocity << x, y, z, p_u, p_v, velocity_x, velocity_y, depthmono;
                featureFrame[feature_id].emplace_back(camera_id, xyz_uv_velocity);
            }
        }
    }

    if (!_img1.empty() && (stereo_cam || depth_cam))
    {
        for (size_t i = 0; i < ids.size(); i++)
        {
            int feature_id = ids[i];
            double x, y, z;
            x = cur_un_pts[i].x;
            y = cur_un_pts[i].y;
            z = 1;
            double p_u, p_v;
            p_u = cur_pts[i].x;
            p_v = cur_pts[i].y;
            int camera_id = 0;
            double velocity_x, velocity_y;
            velocity_x = pts_velocity[i].x;
            velocity_y = pts_velocity[i].y;
            double depth_value = (int)rightImg.at<unsigned short>(round(cur_pts[i].y), round(cur_pts[i].x));
            depth_value = depth_value / 1000;
            // cout << "depth value" << depth_value << endl;

            // 在这里加入box的遍历，判断是否在轮廓内即可
            darknet_ros_msgs::msg::BoundingBoxes::ConstSharedPtr boxes = _boxes;

            darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes.front();
            int lengh = boxes->bounding_boxes.size();
            int insidebox = 0;
            for (int j = 0; j < lengh; j++)
            {
                darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes[j];
                int xmin = box.xmin;
                int ymin = box.ymin;
                int xmax = box.xmax;
                int ymax = box.ymax;

                cv::Rect rect(xmin, ymin, xmax - xmin, ymax - ymin);
                // cv::line(imTrack,Point(50,50),Point(90,70),Scalar(255,0,0),1,8,0);
                cv::rectangle(imTrack, rect, cv::Scalar(0, 128, 255), 5, cv::LINE_8, 0);
                // boxes->bounding_boxes.pop();
                // point inside
                vector<cv::Point2f> contour;
                contour.push_back({xmin, ymin});
                contour.push_back({xmin, ymax});
                contour.push_back({xmax, ymax});
                contour.push_back({xmax, ymin});

                if (double distance = pointPolygonTest(contour, cur_pts[i], true) > 0)
                {
                    insidebox = 1;
                    // cout<<"insidebox"<<insidebox<<endl;
                    continue;
                }
            }
            if (insidebox)
            {
                continue;
            }
            else
            {

                Eigen::Matrix<double, 8, 1> xyz_uv_velocity;
                xyz_uv_velocity << x, y, z, p_u, p_v, velocity_x, velocity_y, depth_value;
                featureFrame[feature_id].emplace_back(camera_id, xyz_uv_velocity);
            }
        }
    }

    // printf("feature track whole time %f\n", t_r.toc());
    return featureFrame;
}

// orinal
//      if (!_img1.empty() && (stereo_cam || depth_cam))
//      {
//          for (size_t i = 0; i < ids_right.size(); i++)
//          {
//              int feature_id = ids_right[i];
//              double x, y ,z;
//              x = cur_un_right_pts[i].x;
//              y = cur_un_right_pts[i].y;
//              z = 1;
//              double p_u, p_v;
//              p_u = cur_right_pts[i].x;
//              p_v = cur_right_pts[i].y;
//              int camera_id = 1;
//              double velocity_x, velocity_y;
//              velocity_x = right_pts_velocity[i].x;
//              velocity_y = right_pts_velocity[i].y;
//              double depth_value=(int)rightImg.at<unsigned short>(round(cur_pts[i].y), round(cur_pts[i].x));
//              depth_value=depth_value/1000;
//              //cout<<"depth value"<<depth_value<<endl;

//             Eigen::Matrix<double, 8, 1> xyz_uv_velocity;
//             xyz_uv_velocity << x, y, z, p_u, p_v, velocity_x, velocity_y,depth_value;
//             featureFrame[feature_id].emplace_back(camera_id,  xyz_uv_velocity);
//         }
//     }

//     //printf("feature track whole time %f\n", t_r.toc());
//     return featureFrame;
// }

void FeatureTracker::rejectWithF()
{
    if (cur_pts.size() >= 8)
    {
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "FM ransac begins");
        TicToc t_f;
        vector<cv::Point2f> un_cur_pts(cur_pts.size()), un_prev_pts(prev_pts.size());
        for (unsigned int i = 0; i < cur_pts.size(); i++)
        {
            Eigen::Vector3d tmp_p;
            m_camera[0]->liftProjective(Eigen::Vector2d(cur_pts[i].x, cur_pts[i].y), tmp_p);
            tmp_p.x() = FOCAL_LENGTH * tmp_p.x() / tmp_p.z() + col / 2.0;
            tmp_p.y() = FOCAL_LENGTH * tmp_p.y() / tmp_p.z() + row / 2.0;
            un_cur_pts[i] = cv::Point2f(tmp_p.x(), tmp_p.y());

            m_camera[0]->liftProjective(Eigen::Vector2d(prev_pts[i].x, prev_pts[i].y), tmp_p);
            tmp_p.x() = FOCAL_LENGTH * tmp_p.x() / tmp_p.z() + col / 2.0;
            tmp_p.y() = FOCAL_LENGTH * tmp_p.y() / tmp_p.z() + row / 2.0;
            un_prev_pts[i] = cv::Point2f(tmp_p.x(), tmp_p.y());
        }

        vector<uchar> status;
        cv::findFundamentalMat(un_cur_pts, un_prev_pts, cv::FM_RANSAC, F_THRESHOLD, 0.99, status);
        int size_a = cur_pts.size();
        reduceVector(prev_pts, status);
        reduceVector(cur_pts, status);
        reduceVector(cur_un_pts, status);
        reduceVector(ids, status);
        reduceVector(track_cnt, status);
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "FM ransac: %d -> %lu: %f", size_a, cur_pts.size(), 1.0 * cur_pts.size() / size_a);
        RCLCPP_DEBUG(rclcpp::get_logger("vins_estimator"), "FM ransac costs: %fms", t_f.toc());
    }
}

void FeatureTracker::readIntrinsicParameter(const vector<string> &calib_file, const int depth)
{
    for (size_t i = 0; i < calib_file.size(); i++)
    {

        RCLCPP_INFO(rclcpp::get_logger("vins_estimator"), "reading paramerter of camera %s", calib_file[i].c_str());
        camodocal::CameraPtr camera = CameraFactory::instance()->generateCameraFromYamlFile(calib_file[i]);
        std::cout << "Testky" << std::endl;

        m_camera.push_back(camera);
    }
    if (calib_file.size() == 2)
        stereo_cam = 1;
    if (depth)
        depth_cam = 1;
}
void FeatureTracker::showUndistortion(const string &name)
{
    cv::Mat undistortedImg(row + 600, col + 600, CV_8UC1, cv::Scalar(0));
    vector<Eigen::Vector2d> distortedp, undistortedp;
    for (int i = 0; i < col; i++)
        for (int j = 0; j < row; j++)
        {
            Eigen::Vector2d a(i, j);
            Eigen::Vector3d b;
            m_camera[0]->liftProjective(a, b);
            distortedp.push_back(a);
            undistortedp.push_back(Eigen::Vector2d(b.x() / b.z(), b.y() / b.z()));
            // printf("%f,%f->%f,%f,%f\n)\n", a.x(), a.y(), b.x(), b.y(), b.z());
        }
    for (int i = 0; i < int(undistortedp.size()); i++)
    {
        cv::Mat pp(3, 1, CV_32FC1);
        pp.at<float>(0, 0) = undistortedp[i].x() * FOCAL_LENGTH + col / 2;
        pp.at<float>(1, 0) = undistortedp[i].y() * FOCAL_LENGTH + row / 2;
        pp.at<float>(2, 0) = 1.0;
        // cout << trackerData[0].K << endl;
        // printf("%lf %lf\n", p.at<float>(1, 0), p.at<float>(0, 0));
        // printf("%lf %lf\n", pp.at<float>(1, 0), pp.at<float>(0, 0));
        if (pp.at<float>(1, 0) + 300 >= 0 && pp.at<float>(1, 0) + 300 < row + 600 && pp.at<float>(0, 0) + 300 >= 0 && pp.at<float>(0, 0) + 300 < col + 600)
        {
            undistortedImg.at<uchar>(pp.at<float>(1, 0) + 300, pp.at<float>(0, 0) + 300) = cur_img.at<uchar>(distortedp[i].y(), distortedp[i].x());
        }
        else
        {
            // ROS_ERROR("(%f %f) -> (%f %f)", distortedp[i].y, distortedp[i].x, pp.at<float>(1, 0), pp.at<float>(0, 0));
        }
    }
    cv::imshow(name, undistortedImg);
    cv::waitKey(0);
}

vector<cv::Point2f> FeatureTracker::undistortedPts(vector<cv::Point2f> &pts, camodocal::CameraPtr cam)
{
    vector<cv::Point2f> un_pts;
    for (unsigned int i = 0; i < pts.size(); i++)
    {
        Eigen::Vector2d a(pts[i].x, pts[i].y);
        Eigen::Vector3d b;
        cam->liftProjective(a, b);
        un_pts.push_back(cv::Point2f(b.x() / b.z(), b.y() / b.z()));
    }
    return un_pts;
}

vector<cv::Point2f> FeatureTracker::ptsVelocity(vector<int> &ids, vector<cv::Point2f> &pts,
                                                map<int, cv::Point2f> &cur_id_pts, map<int, cv::Point2f> &prev_id_pts)
{
    vector<cv::Point2f> pts_velocity;
    cur_id_pts.clear();
    for (unsigned int i = 0; i < ids.size(); i++)
    {
        cur_id_pts.insert(make_pair(ids[i], pts[i]));
    }

    // caculate points velocity
    if (!prev_id_pts.empty())
    {
        double dt = cur_time - prev_time;

        for (unsigned int i = 0; i < pts.size(); i++)
        {
            std::map<int, cv::Point2f>::iterator it;
            it = prev_id_pts.find(ids[i]);
            if (it != prev_id_pts.end())
            {
                double v_x = (pts[i].x - it->second.x) / dt;
                double v_y = (pts[i].y - it->second.y) / dt;
                pts_velocity.push_back(cv::Point2f(v_x, v_y));
            }
            else
                pts_velocity.push_back(cv::Point2f(0, 0));
        }
    }
    else
    {
        for (unsigned int i = 0; i < cur_pts.size(); i++)
        {
            pts_velocity.push_back(cv::Point2f(0, 0));
        }
    }
    return pts_velocity;
}

void FeatureTracker::drawTrack(const cv::Mat &imLeft, const cv::Mat &imRight,
                               vector<int> &curLeftIds,
                               vector<cv::Point2f> &curLeftPts,
                               vector<cv::Point2f> &curRightPts,
                               map<int, cv::Point2f> &prevLeftPtsMap)
{
    // int rows = imLeft.rows;
    int cols = imLeft.cols;
    if (!imRight.empty() && (stereo_cam))
        cv::hconcat(imLeft, imRight, imTrack);
    else
        imTrack = imLeft.clone();
    cv::cvtColor(imTrack, imTrack, CV_GRAY2RGB);

    for (size_t j = 0; j < curLeftPts.size(); j++)
    {
        double len = std::min(1.0, 1.0 * track_cnt[j] / 20);
        cv::circle(imTrack, curLeftPts[j], 2, cv::Scalar(255 * (1 - len), 0, 255 * len), 6); // point
    }
    if (!imRight.empty() && (stereo_cam))
    {
        for (size_t i = 0; i < curRightPts.size(); i++)
        {
            cv::Point2f rightPt = curRightPts[i];
            rightPt.x += cols;
            cv::circle(imTrack, rightPt, 2, cv::Scalar(0, 255, 0), 6);
            // cv::Point2f leftPt = curLeftPtsTrackRight[i];
            // cv::line(imTrack, leftPt, rightPt, cv::Scalar(0, 255, 0), 1, 8, 0);
        }
    }

    map<int, cv::Point2f>::iterator mapIt;
    for (size_t i = 0; i < curLeftIds.size(); i++)
    {
        int id = curLeftIds[i];
        mapIt = prevLeftPtsMap.find(id);
        if (mapIt != prevLeftPtsMap.end())
        {
            cv::arrowedLine(imTrack, curLeftPts[i], mapIt->second, cv::Scalar(0, 255, 0), 3, 8, 0, 0.2); // green line shows changes
        }
    }

    // draw prediction
    /*
    for(size_t i = 0; i < predict_pts_debug.size(); i++)
    {
        cv::circle(imTrack, predict_pts_debug[i], 2, cv::Scalar(0, 170, 255), 2);
    }
    */
    // printf("predict pts size %d \n", (int)predict_pts_debug.size());

    // cv::Mat imCur2Compress;
    // cv::resize(imCur2, imCur2Compress, cv::Size(cols, rows / 2));

    // cv::imshow("point_tracking", imTrack);
    cv::waitKey(2);
}

void FeatureTracker::drawTrackbox(const darknet_ros_msgs::msg::BoundingBoxes::ConstSharedPtr &_boxes, const cv::Mat &imLeft, const cv::Mat &imRight,
                                  vector<int> &curLeftIds,
                                  vector<cv::Point2f> &curLeftPts,
                                  vector<cv::Point2f> &curRightPts,
                                  map<int, cv::Point2f> &prevLeftPtsMap)
{
    // int rows = imLeft.rows;
    int cols = imLeft.cols;
    if (!imRight.empty() && (stereo_cam))
        cv::hconcat(imLeft, imRight, imTrack); // 拼接函数
    else
        imTrack = imLeft.clone();
    cv::cvtColor(imTrack, imTrack, CV_GRAY2RGB);

    for (size_t j = 0; j < curLeftPts.size(); j++)
    {
        double len = std::min(1.0, 1.0 * track_cnt[j] / 20);
        cv::circle(imTrack, curLeftPts[j], 2, cv::Scalar(255 * (1 - len), 0, 255 * len), 6); // point  渐变点len越小，颜色越蓝，点的质量越差
    }
    if (!imRight.empty() && (stereo_cam)) // 双目就把两者联系起来
    {
        for (size_t i = 0; i < curRightPts.size(); i++)
        {
            cv::Point2f rightPt = curRightPts[i];
            rightPt.x += cols;
            cv::circle(imTrack, rightPt, 2, cv::Scalar(0, 255, 0), 6);
            // cv::Point2f leftPt = curLeftPtsTrackRight[i];
            // cv::line(imTrack, leftPt, rightPt, cv::Scalar(0, 255, 0), 1, 8, 0);
        }
    }

    map<int, cv::Point2f>::iterator mapIt;
    for (size_t i = 0; i < curLeftIds.size(); i++)
    {
        int id = curLeftIds[i];
        mapIt = prevLeftPtsMap.find(id);
        if (mapIt != prevLeftPtsMap.end())
        {
            cv::arrowedLine(imTrack, curLeftPts[i], mapIt->second, cv::Scalar(0, 255, 0), 3, 8, 0, 0.2); // green line shows changes  绿色线条代表剧烈变动
        }
    }

    // darknet_ros_msgs::BoundingBoxes boxes = _boxes->bounding_boxes;
    // for (int j = 0; j < boxes.size(); j++)
    // {
    //     darknet_ros_msgs::BoundingBox box = boxes.front();
    //     int xmin = box.xmin;
    //     int ymin = box.ymin;
    //     int xmax = box.xmax;
    //     int ymax = box.ymax;
    //     boxes.pop();
    // }

    darknet_ros_msgs::msg::BoundingBoxes::ConstSharedPtr boxes = _boxes;

    darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes.front();
    int lengh = boxes->bounding_boxes.size();
    for (int j = 0; j < lengh; j++)
    {
        darknet_ros_msgs::msg::BoundingBox box = boxes->bounding_boxes[j];
        int xmin = box.xmin;
        int ymin = box.ymin;
        int xmax = box.xmax;
        int ymax = box.ymax;

        cv::Rect rect(xmin, ymin, xmax - xmin, ymax - ymin);
        // cv::line(imTrack,Point(50,50),Point(90,70),Scalar(255,0,0),1,8,0);
        cv::rectangle(imTrack, rect, cv::Scalar(0, 128, 255), 5, cv::LINE_8, 0);
        // boxes->bounding_boxes.pop();
        // point inside
        vector<cv::Point2f> contour;
        contour.push_back({xmin, ymin});
        contour.push_back({xmin, ymax});
        contour.push_back({xmax, ymax});
        contour.push_back({xmax, ymin});
        for (size_t j = 0; j < curLeftPts.size(); j++)
        {
            if (double distance = pointPolygonTest(contour, curLeftPts[j], true) > 0)

                cv::circle(imTrack, curLeftPts[j], 2, cv::Scalar(0, 255, 255), 6); // point  渐变点len越小，颜色越蓝，点的质量越差
        }
    }

    // draw prediction
    /*
    for(size_t i = 0; i < predict_pts_debug.size(); i++)
    {
        cv::circle(imTrack, predict_pts_debug[i], 2, cv::Scalar(0, 170, 255), 2);
    }
    */
    // printf("predict pts size %d \n", (int)predict_pts_debug.size());

    // cv::Mat imCur2Compress;
    // cv::resize(imCur2, imCur2Compress, cv::Size(cols, rows / 2));

    // cv::imshow("point_tracking", imTrack);
    cv::waitKey(2);
}

void FeatureTracker::setPrediction(map<int, Eigen::Vector3d> &predictPts)
{
    hasPrediction = true;
    predict_pts.clear();
    predict_pts_debug.clear();
    map<int, Eigen::Vector3d>::iterator itPredict;
    for (size_t i = 0; i < ids.size(); i++)
    {
        // printf("prevLeftId size %d prevLeftPts size %d\n",(int)prevLeftIds.size(), (int)prevLeftPts.size());
        int id = ids[i];
        itPredict = predictPts.find(id);
        if (itPredict != predictPts.end())
        {
            Eigen::Vector2d tmp_uv;
            m_camera[0]->spaceToPlane(itPredict->second, tmp_uv);
            predict_pts.push_back(cv::Point2f(tmp_uv.x(), tmp_uv.y()));
            predict_pts_debug.push_back(cv::Point2f(tmp_uv.x(), tmp_uv.y()));
        }
        else
            predict_pts.push_back(prev_pts[i]);
    }
}

void FeatureTracker::removeOutliers(set<int> &removePtsIds)
{
    std::set<int>::iterator itSet;
    vector<uchar> status;
    for (size_t i = 0; i < ids.size(); i++)
    {
        itSet = removePtsIds.find(ids[i]);
        if (itSet != removePtsIds.end())
            status.push_back(0);
        else
            status.push_back(1);
    }

    reduceVector(prev_pts, status);
    reduceVector(ids, status);
    reduceVector(track_cnt, status);
}

cv::Mat FeatureTracker::getTrackImage()
{
    return imTrack;
}